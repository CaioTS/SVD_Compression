from __future__ import absolute_import, division
from __future__ import print_function, unicode_literals

import tensorflow as tf

import tensorflow as tf

from tensorflow.keras import layers
from tensorflow.keras import initializers
from tensorflow.keras import optimizers

import l0_reg as regs_with_l0
#import MyCustomCallback as mcc


class Lenet5_l0:

    def __init__(self, NORM = False):
        if NORM:
            self.param_def_norm()
        else:
            self.param_def()
        self.def_model()
        self.load_dataset()
        print("\n\t\tcall train_lenet_300_100() function to train your networ\n")
        print("\t\tprune_model_wo_ft() and prune_model() functions available\n")


    def param_def(self):
        # # # # # # # # # # # # # # # # # #
        # defining constants
        # # # # # # # # # # # # # # # # # #
        # fit hyperparameters
        epochs = 500
        learn_rate = 0.0005
        batch_size = 256
        epochs_to_prune = 5
        epochs_to_start_prune = epochs
        pruning_times = 50
        model_name = '../models/mnist-lenet-5.h5'
        model_pruned_name = '../models/mnist-lenet-5-pruned.h5'

        # network hyperparameters
        input_shape = (28, 28, 1)
        n_classes = 10
        n_hidden_1 = 500
        keep_prob_1 = 0.1
        keep_prob_2 = False

        reg_conv_type = 'l0'
        reg_type = 'l0'
        # 1st Convolutional regularizations
        conv1_alpha_l2 = 0.e-05
        conv1_alpha_l1 = 0.e-05
        conv1_alpha_l0 = 20.e-06
        conv1_beta = 20
        conv1_l0_bias = 4.0e-05/conv1_beta
        conv1_l1_bias = 0 #6.0e-05
        # 2nd Convolutional regularizations
        conv2_alpha_l2 = 0.e-04
        conv2_alpha_l1 = 0.e-04
        conv2_alpha_l0 = 2e-05
        conv2_beta = 20
        conv2_l0_bias = 4.0e-05/conv2_beta
        conv2_l1_bias = 0 #6.0e-05

        # 1st FC regularizations
        FC1_alpha_l2 = 0.e-04
        FC1_alpha_l1 = 0.e-04
        FC1_alpha_l0 = 60.e-06
        FC1_beta = 20
        FC1_l0_bias = 6.0e-05/FC1_beta
        FC1_l1_bias = 0 #6.0e-05
        # 2nd FC regularizations
        FC2_alpha_l2 = 0.1e-04
        FC2_alpha_l1 = 0 #0.5e-04
        FC2_alpha_l0 = 100.e-06
        FC2_beta = 20
        FC2_l0_bias = 6.0e-05/FC2_beta
        FC2_l1_bias = 0 #6.0e-05

        # prune hyperparameters
        threshold = 0.0055
        fine_tune_times = 5
        fine_tune_epochs = 5


        self.dict_params = {'keep_prob_1': keep_prob_1,
                            'keep_prob_2': keep_prob_2,
                            'model_name' : model_name,
                            'model_pruned_name' : model_pruned_name,
                            'conv1_alpha_l0': conv1_alpha_l0,
                            'conv1_alpha_l1': conv1_alpha_l1,
                            'conv1_alpha_l2': conv1_alpha_l2,
                            'conv1_l0_bias': conv1_l0_bias,
                            'conv1_l1_bias': conv1_l1_bias,
                            'conv1_l2_bias': 0.0,
                            'conv1_beta': conv1_beta,
                            'conv2_alpha_l0': conv2_alpha_l0,
                            'conv2_alpha_l1': conv2_alpha_l1,
                            'conv2_alpha_l2': conv2_alpha_l2,
                            'conv2_l0_bias': conv2_l0_bias,
                            'conv2_l1_bias': conv2_l1_bias,
                            'conv2_l2_bias': 0.0,
                            'conv2_beta': conv2_beta,
                            'FC1_alpha_l0': FC1_alpha_l0,
                            'FC1_alpha_l1': FC1_alpha_l1,
                            'FC1_alpha_l2': FC1_alpha_l2,
                            'FC1_l0_bias': FC1_l0_bias,
                            'FC1_l1_bias': FC1_l1_bias,
                            'FC1_l2_bias': 0.0,
                            'FC1_beta': FC1_beta,
                            'FC2_alpha_l0': FC2_alpha_l0,
                            'FC2_alpha_l1': FC2_alpha_l1,
                            'FC2_alpha_l2': FC2_alpha_l2,
                            'FC2_l0_bias': FC2_l0_bias,
                            'FC2_l1_bias': FC2_l1_bias,
                            'FC2_l2_bias': 0.0,
                            'FC2_beta': FC2_beta,
                            'input_shape': input_shape,
                            'batch_size' : batch_size,
                            'fine_tune_times': fine_tune_times,
                            'fine_tune_epochs': fine_tune_epochs,
                            'threshold' : threshold,
                            'epochs_to_prune': epochs_to_prune,
                            'n_hidden_1': n_hidden_1,
                            'learn_rate': learn_rate}


    def param_def_norm(self):
        # # # # # # # # # # # # # # # # # #
        # defining constants
        # # # # # # # # # # # # # # # # # #
        # fit hyperparameters
        epochs = 500
        learn_rate = 0.0005
        batch_size = 256
        epochs_to_prune = 5
        epochs_to_start_prune = epochs
        pruning_times = 50
        model_name = '../models/mnist-lenet-5.h5'
        model_pruned_name = '../models/mnist-lenet-5-pruned.h5'

        # network hyperparameters
        input_shape = (28, 28, 1)
        n_classes = 10
        n_hidden_1 = 500
        keep_prob_1 = 0.1
        keep_prob_2 = False

        reg_conv_type = 'l0'
        reg_type = 'l0'

        alpha_l0_is = 2e-4
        alpha_l2_is = 6e-5
        l0_bias_is = 4e-6
        beta_is = 40

        model_name = '../models/mnist-lenet-5.h5'
        model_pruned_name = '../models/mnist-lenet-5-pruned.h5'

        print('alpha_l0: %f\t beta: %d\t alpha_l2: %f\t alpha_l0_bias: %f\n' % (alpha_l0_is, beta_is, alpha_l2_is, l0_bias_is))
    
        conv1_alpha_l0 = alpha_l0_is * (1+(500-431080)/431080)
        conv2_alpha_l0 = alpha_l0_is * (1+(25000-431080)/431080)
        FC1_alpha_l0 = alpha_l0_is * (1+(400000-431080)/431080)
        FC2_alpha_l0 = alpha_l0_is * (1+(5000-431080)/431080)
    
        conv1_alpha_l2 = alpha_l2_is * (1+(500-431080)/431080)
        conv2_alpha_l2 = alpha_l2_is * (1+(25000-431080)/431080)
        FC1_alpha_l2 = alpha_l2_is * (1+(400000-431080)/431080)
        FC2_alpha_l2 = alpha_l2_is * (1+(5000-431080)/431080)
       
        conv1_l0_bias = l0_bias_is * (1+(20-431080)/431080)
        conv2_l0_bias = l0_bias_is * (1+(50-431080)/431080)
        FC1_l0_bias = l0_bias_is * (1+(500-431080)/431080)
        FC2_l0_bias = l0_bias_is * (1+(10-431080)/431080)
    
        conv1_beta = beta_is
        conv2_beta = beta_is
        FC1_beta = beta_is
        FC2_beta = beta_is
    
        # prune hyperparameters
        threshold = 0.0055
        fine_tune_times = 5
        fine_tune_epochs = 5

        self.dict_params = {'keep_prob_1': keep_prob_1,
                            'keep_prob_2': keep_prob_2,
                            'model_name' : model_name,
                            'model_pruned_name' : model_pruned_name,
                            'conv1_alpha_l0': conv1_alpha_l0,
                            'conv1_alpha_l1': conv1_alpha_l1,
                            'conv1_alpha_l2': conv1_alpha_l2,
                            'conv1_l0_bias': conv1_l0_bias,
                            'conv1_l1_bias': conv1_l1_bias,
                            'conv1_l2_bias': 0.0,
                            'conv1_beta': conv1_beta,
                            'conv2_alpha_l0': conv2_alpha_l0,
                            'conv2_alpha_l1': conv2_alpha_l1,
                            'conv2_alpha_l2': conv2_alpha_l2,
                            'conv2_l0_bias': conv2_l0_bias,
                            'conv2_l1_bias': conv2_l1_bias,
                            'conv2_l2_bias': 0.0,
                            'conv2_beta': conv2_beta,
                            'FC1_alpha_l0': FC1_alpha_l0,
                            'FC1_alpha_l1': FC1_alpha_l1,
                            'FC1_alpha_l2': FC1_alpha_l2,
                            'FC1_l0_bias': FC1_l0_bias,
                            'FC1_l1_bias': FC1_l1_bias,
                            'FC1_l2_bias': 0.0,
                            'FC1_beta': FC1_beta,
                            'FC2_alpha_l0': FC2_alpha_l0,
                            'FC2_alpha_l1': FC2_alpha_l1,
                            'FC2_alpha_l2': FC2_alpha_l2,
                            'FC2_l0_bias': FC2_l0_bias,
                            'FC2_l1_bias': FC2_l1_bias,
                            'FC2_l2_bias': 0.0,
                            'FC2_beta': FC2_beta,
                            'batch_size' : batch_size,
                            'input_shape': input_shape,
                            'fine_tune_times': fine_tune_times,
                            'fine_tune_epochs': fine_tune_epochs,
                            'threshold' : threshold,
                            'epochs_to_prune': epochs_to_prune,
                            'n_hidden_1': n_hidden_1,
                            'learn_rate': learn_rate}
    

    def def_model(self):
    # # # # # # # # # # # # # # # # # # # # #
    # defining lenet-5 model
    
        init_weights = initializers.RandomNormal(stddev=0.01)

        reg_weights_conv1 = regs_with_l0.l0_exp(self.dict_params['conv1_alpha_l0'],
                                                self.dict_params['conv1_alpha_l1'],
                                                self.dict_params['conv1_alpha_l2'],
                                                self.dict_params['conv1_beta'])
        reg_biases_conv1 = regs_with_l0.l0_exp(self.dict_params['conv1_l0_bias'],
                                               self.dict_params['conv1_l1_bias'],
                                               self.dict_params['conv1_l2_bias'],
                                               self.dict_params['conv1_beta'])

        reg_weights_conv2 = regs_with_l0.l0_exp(self.dict_params['conv2_alpha_l0'],
                                                self.dict_params['conv2_alpha_l1'],
                                                self.dict_params['conv2_alpha_l2'],
                                                self.dict_params['conv2_beta'])
        reg_biases_conv2 = regs_with_l0.l0_exp(self.dict_params['conv2_l0_bias'],
                                               self.dict_params['conv2_l1_bias'],
                                               self.dict_params['conv2_l2_bias'],
                                               self.dict_params['conv2_beta'])

        reg_weights_FC1 = regs_with_l0.l0_exp(self.dict_params['FC1_alpha_l0'],
                                              self.dict_params['FC1_alpha_l1'],
                                              self.dict_params['FC1_alpha_l2'],
                                              self.dict_params['FC1_beta'])
        reg_biases_FC1 = regs_with_l0.l0_exp(self.dict_params['FC1_l0_bias'],
                                             self.dict_params['FC1_l1_bias'],
                                             self.dict_params['FC1_l2_bias'],
                                             self.dict_params['FC1_beta'])

        reg_weights_FC2 = regs_with_l0.l0_exp(self.dict_params['FC2_alpha_l0'],
                                              self.dict_params['FC2_alpha_l1'],
                                              self.dict_params['FC2_alpha_l2'],
                                              self.dict_params['FC2_beta'])
        reg_biases_FC2 = regs_with_l0.l0_exp(self.dict_params['FC2_l0_bias'],
                                             self.dict_params['FC2_l1_bias'],
                                             self.dict_params['FC2_l2_bias'],
                                             self.dict_params['FC2_beta'])

        # Defining model Lenet-5
        self.model = tf.keras.Sequential()

        self.model.add(layers.Conv2D(20, kernel_size=(5, 5),
                                activation='relu',
                                padding='valid',
                                input_shape=self.dict_params['input_shape'],
                                kernel_regularizer=reg_weights_conv1,
                                bias_regularizer=reg_biases_conv1,
                                strides=1))
        self.model.add(layers.MaxPooling2D(pool_size=(2, 2), strides=2))

        self.model.add(layers.Conv2D(50, kernel_size=(5, 5),
                                activation='relu',
                                padding='valid',
                                kernel_regularizer=reg_weights_conv2,
                                bias_regularizer=reg_biases_conv2,
                                strides=1))
        self.model.add(layers.MaxPooling2D(pool_size=(2, 2), strides=2))
        self.model.add(layers.Flatten())

        if self.dict_params['keep_prob_1']:
            self.model.add(layers.Dropout(self.dict_params['keep_prob_1']))

        self.model.add(layers.Dense(self.dict_params['n_hidden_1'], activation='relu',
                               input_shape=(self.dict_params['input_shape'],),
                               kernel_initializer=init_weights,
                               bias_initializer=init_weights,
                               kernel_regularizer=reg_weights_FC1,
                               bias_regularizer=reg_biases_FC1))
        if self.dict_params['keep_prob_2']:
            self.model.add(layers.Dropout(self.dict_params['keep_prob_2']))

        self.model.add(layers.Dense(10, activation='softmax',
                               kernel_regularizer=reg_weights_FC2,
                               bias_regularizer=reg_biases_FC2))

        # self.model training
        opt = optimizers.Adam(lr=self.dict_params['learn_rate'],
                              beta_1=0.9, beta_2=0.999,
                              epsilon=1e-08, weight_decay=0.0,
                              amsgrad=False)

        self.model.compile(loss='categorical_crossentropy',
                      optimizer=opt,
                      metrics=['accuracy'])


    def load_dataset(self):
        # # # # # # # # # # # # # # # # # #
        # loading dataset
        # # # # # # # # # # # # # # # # # #
        img_rows, img_cols = 28, 28

        # loading data
        (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
        x_train = x_train.reshape(x_train.shape[0], img_rows, img_cols, 1)
        x_test = x_test.reshape(x_test.shape[0], img_rows, img_cols, 1)

        # pre-processing
        self.x_train = x_train.astype('float32')
        self.x_test = x_test.astype('float32')
        self.x_train /= 255
        self.x_test /= 255

        self.y_train = tf.keras.utils.to_categorical(y_train,
                                        num_classes=10,
                                        dtype='float')
        self.y_test = tf.keras.utils.to_categorical(y_test,
                                       num_classes=10,
                                       dtype='float')

    def train(self):
    
        # Training model
        init_time = time.time()
        self.model.fit(self.x_train, self.y_train, epochs=self.dict_params['epochs'],
                  batch_size=self.dict_params['batch_size'],
                  validation_data=(self.x_test, self.y_test))
        end_time = time.time()
        print("Time elapsed in training: %f seconds" % (end_time - init_time))
        self.model.save_weights(self.dict_params['model_name'])


    def prune_model_wo_ft(self):
        # processing mnist dataset

        weights_model = self.model.get_weights()
        loss, acc = self.model.evaluate(x=self.x_test, y=self.y_test, batch_size=256)
        compl = regs_with_l0.calc_complexity(self.model.get_weights())
        print("Acc/Compl before pruning: %f\t%d" % (acc, compl))

        self.model.set_weights(regs_with_l0.weight_fc_prune(weights_model, self.dict_params['threshold']))
        self.model.save_weights(self.dict_params['model_pruned_name'])

        loss, acc = self.model.evaluate(x=self.x_test, y=self.y_test, batch_size=256)
        compl = regs_with_l0.calc_complexity(self.model.get_weights())

        self.model.save_weights(self.dict_params['model_pruned_name'])

        del weights_model
        print("Acc/Compl after pruning: %f\t%d" % (acc, compl))

    def prune_model(self):
        # processing mnist dataset
        loss, acc = self.model.evaluate(x=self.x_test, y=self.y_test, batch_size=256)
        compl = regs_with_l0.calc_complexity(self.model.get_weights())
        print("Acc/Compl before pruning: %f\t%d" % (acc, compl))

        for i in range(self.dict_params['ft_times']):
            weights_model = self.model.get_weights()
            self.model.set_weights(regs_with_l0.weight_fc_prune(weights_model, self.dict_params['threshold']))
            loss, acc = self.model.evaluate(x=self.x_test, y=self.y_test, batch_size=256)
            compl = regs_with_l0.calc_complexity(self.model.get_weights())
            print("Acc/Compl after pruning #%d:  %f\t%d" % (i, acc, compl))
            self.model.fit(self.x_train, self.y_train, epochs=self.dict_params['epochs_to_prune'],
                      batch_size=self.dict_params['batch_size'],
                      validation_data=(self.x_test, self.y_test))

        self.model.save_weights(self.dict_params['model_pruned_name'])

