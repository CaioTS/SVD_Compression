import time

import tensorflow as tf
from tensorflow.keras import layers

import l0_reg as regs_with_l0

def lr_schedule(epoch):
    """Learning Rate Schedule
    Learning rate is scheduled to be reduced after 80, 120, 160, 180 epochs.
    Called automatically every epoch as part of callbacks during training.
    # Arguments
        epoch (int): The number of epochs
    # Returns
        lr (float32): learning rate
    """
    lr = 1e-3
    if epoch > 180:
        lr *= 0.5e-3
    elif epoch > 160:
        lr *= 1e-3
    elif epoch > 120:
        lr *= 1e-2
    elif epoch > 80:
        lr *= 1e-1
    print('Learning rate: ', lr)
    return lr


class Lenet300100_l0:

    def __init__(self, NORM = False):
        if NORM:
            self.param_def_norm()
        else:
            self.param_def()
        self.def_model()
        self.load_dataset()
        print("\n\t\tcall train() function to train your networ\n")
        print("\t\tprune_model_wo_ft() and prune_model() functions available\n")


    def param_def(self):
        # hyperparameters definition
        learn_rate = 0.001
        batch_size = 256
        epochs = 500
        model_name = '../models/mnist-300-100.h5'
        model_pruned_name = '../models/mnist-300-100-pruned.h5'

        ft_times = 10
        epochs_to_prune = 2
        threshold = 0.0055

        keep_prob = 0.1

        alpha_l2_FC1 = 0.0e-5
        alpha_l1_FC1 = 0.0e-3
        alpha_l0_FC1 = 25e-6
        alpha_l2_bias_FC1 = 0.0e-5
        alpha_l1_bias_FC1 = 0.0e-3
        alpha_l0_bias_FC1 = 25e-6
        beta_FC1 = 10

        alpha_l2_FC2 = 1.0e-5
        alpha_l1_FC2 = 0.0e-3
        alpha_l0_FC2 = 100e-6
        alpha_l2_bias_FC2 = 0.0e-3
        alpha_l1_bias_FC2 = 0.0e-3
        alpha_l0_bias_FC2 = 100e-6
        beta_FC2 = 10

        alpha_l2_FC3 = 0.0e-5
        alpha_l1_FC3 = 0.0e-3
        alpha_l0_FC3 = 100e-6
        alpha_l2_bias_FC3 = 0.0e-3
        alpha_l1_bias_FC3 = 0.0e-3
        alpha_l0_bias_FC3 = 100e-6
        beta_FC3 = 10

        self.dict_params = {'alpha_l2_FC1': alpha_l2_FC1,
                            'alpha_l1_FC1': alpha_l1_FC1,
                            'alpha_l0_FC1': alpha_l0_FC1,
                            'alpha_l2_bias_FC1': alpha_l2_bias_FC1,
                            'alpha_l1_bias_FC1': alpha_l1_bias_FC1,
                            'alpha_l0_bias_FC1': alpha_l0_bias_FC1,
                            'beta_FC1': beta_FC1,
                            'alpha_l2_FC2': alpha_l2_FC2,
                            'alpha_l1_FC2': alpha_l1_FC2,
                            'alpha_l0_FC2': alpha_l0_FC2,
                            'alpha_l2_bias_FC2': alpha_l2_bias_FC2,
                            'alpha_l1_bias_FC2': alpha_l1_bias_FC2,
                            'alpha_l0_bias_FC2': alpha_l0_bias_FC2,
                            'beta_FC2': beta_FC2,
                            'alpha_l2_FC3': alpha_l2_FC3,
                            'alpha_l1_FC3': alpha_l1_FC3,
                            'alpha_l0_FC3': alpha_l0_FC3,
                            'alpha_l2_bias_FC3': alpha_l2_bias_FC3,
                            'alpha_l1_bias_FC3': alpha_l1_bias_FC3,
                            'alpha_l0_bias_FC3': alpha_l0_bias_FC3,
                            'model_name' : model_name,
                            'model_pruned_name' : model_pruned_name,
                            'beta_FC3': beta_FC3,
                            'batch_size': batch_size,
                            'keep_prob': keep_prob,
                            'learn_rate': learn_rate,
                            'threshold': threshold,
                            'ft_times' : ft_times,
                            'epochs_to_prune':epochs_to_prune,
                            'epochs': epochs}


    def param_def_norm(self):
        # hyperparameters definition
        learn_rate = 0.001
        batch_size = 256
        epochs = 500
        model_name = '../models/mnist-300-100.h5'
        model_pruned_name = '../models/mnist-300-100-pruned.h5'

        ft_times = 10
        epochs_to_prune = 2
        keep_prob = 0.1
        threshold = 0.0055

        FC1_ratio = 1-(235200-266610)/266610
        FC1_bias_ratio = 1-(300-266610)/266610
        FC2_ratio = 1-(30000-266610)/266610
        FC2_bias_ratio = 1-(100-266610)/266610
        FC3_ratio = 1-(1000-266610)/266610
        FC3_bias_ratio = 1-(10-266610)/266610

        alpha_l0 = 25e-6
        alpha_l2 = 0.01e-6
        beta = 10

        alpha_l2_FC1 = alpha_l2*FC1_ratio
        alpha_l1_FC1 = 0.0e-3
        alpha_l0_FC1 = alpha_l0*FC1_ratio
        alpha_l2_bias_FC1 = 0
        alpha_l1_bias_FC1 = 0.0e-3
        alpha_l0_bias_FC1 = alpha_l0*FC1_bias_ratio
        beta_FC1 = 10

        alpha_l2_FC2 = alpha_l2*FC2_ratio
        alpha_l1_FC2 = 0.0e-3
        alpha_l0_FC2 = alpha_l0*FC2_ratio
        alpha_l2_bias_FC2 = 0
        alpha_l1_bias_FC2 = 0.0e-3
        alpha_l0_bias_FC2 = alpha_l0*FC2_bias_ratio
        beta_FC2 = 10

        alpha_l2_FC3 = alpha_l2*FC3_ratio
        alpha_l1_FC3 = 0.0e-3
        alpha_l0_FC3 = alpha_l0*FC3_ratio
        alpha_l2_bias_FC3 = 0
        alpha_l1_bias_FC3 = 0.0e-3
        alpha_l0_bias_FC3 = alpha_l0*FC3_bias_ratio
        beta_FC3 = 10

        self.dict_params = {'alpha_l2_FC1': alpha_l2_FC1,
                            'alpha_l1_FC1': alpha_l1_FC1,
                            'alpha_l0_FC1': alpha_l0_FC1,
                            'alpha_l2_bias_FC1': alpha_l2_bias_FC1,
                            'alpha_l1_bias_FC1': alpha_l1_bias_FC1,
                            'alpha_l0_bias_FC1': alpha_l0_bias_FC1,
                            'beta_FC1': beta_FC1,
                            'alpha_l2_FC2': alpha_l2_FC2,
                            'alpha_l1_FC2': alpha_l1_FC2,
                            'alpha_l0_FC2': alpha_l0_FC2,
                            'alpha_l2_bias_FC2': alpha_l2_bias_FC2,
                            'alpha_l1_bias_FC2': alpha_l1_bias_FC2,
                            'alpha_l0_bias_FC2': alpha_l0_bias_FC2,
                            'beta_FC2': beta_FC2,
                            'alpha_l2_FC3': alpha_l2_FC3,
                            'alpha_l1_FC3': alpha_l1_FC3,
                            'alpha_l0_FC3': alpha_l0_FC3,
                            'alpha_l2_bias_FC3': alpha_l2_bias_FC3,
                            'alpha_l1_bias_FC3': alpha_l1_bias_FC3,
                            'alpha_l0_bias_FC3': alpha_l0_bias_FC3,
                            'model_name' : model_name,
                            'model_pruned_name' : model_pruned_name,
                            'beta_FC3': beta_FC3,
                            'batch_size': batch_size,
                            'keep_prob': keep_prob,
                            'learn_rate': learn_rate,
                            'ft_times' : ft_times,
                            'threshold': threshold,
                            'epochs_to_prune':epochs_to_prune,
                            'epochs': epochs}

    def def_model(self):
        # # # # # # # # # # # # # # # # # # # # #
        # defining lenet-300-100 model
        self.model = tf.keras.Sequential()


        reg_FC1 = regs_with_l0.l0_exp(self.dict_params['alpha_l0_FC1'],
                                      self.dict_params['alpha_l1_FC1'],
                                      self.dict_params['alpha_l2_FC1'],
                                      self.dict_params['beta_FC1'])

        reg_bias_FC1 = regs_with_l0.l0_exp(self.dict_params['alpha_l0_bias_FC1'],
                                           self.dict_params['alpha_l1_bias_FC1'],
                                           self.dict_params['alpha_l2_bias_FC1'],
                                           self.dict_params['beta_FC1'])

        self.model.add(layers.Dense(300, activation='relu',
                           kernel_regularizer=reg_FC1,
                           bias_regularizer=reg_bias_FC1))
        if self.dict_params['keep_prob']:
            self.model.add(layers.Dropout(self.dict_params['keep_prob']))

        reg_FC2 = regs_with_l0.l0_exp(self.dict_params['alpha_l0_FC2'],
                                          self.dict_params['alpha_l1_FC2'],
                                          self.dict_params['alpha_l2_FC2'],
                                          self.dict_params['beta_FC2'])

        reg_bias_FC2 = regs_with_l0.l0_exp(self.dict_params['alpha_l0_bias_FC2'],
                                       self.dict_params['alpha_l1_bias_FC2'],
                                       self.dict_params['alpha_l2_bias_FC2'],
                                       self.dict_params['beta_FC2'])

        self.model.add(layers.Dense(100, activation='relu',
                                    kernel_regularizer=reg_FC2,
                                    bias_regularizer=reg_bias_FC2))

        if self.dict_params['keep_prob']:
            self.model.add(layers.Dropout(self.dict_params['keep_prob']))

        reg_FC3 = regs_with_l0.l0_exp(self.dict_params['alpha_l0_FC3'],
                                      self.dict_params['alpha_l1_FC3'],
                                      self.dict_params['alpha_l2_FC3'],
                                      self.dict_params['beta_FC3'])

        reg_bias_FC3 = regs_with_l0.l0_exp(self.dict_params['alpha_l0_bias_FC3'],
                                           self.dict_params['alpha_l1_bias_FC3'],
                                           self.dict_params['alpha_l2_bias_FC3'],
                                           self.dict_params['beta_FC3'])

        self.model.add(layers.Dense(10, kernel_regularizer=reg_FC3,
                                    bias_regularizer=reg_bias_FC3,
                                    activation='softmax'))

        self.model.compile(optimizer=tf.keras.optimizers.
                           Adam(self.dict_params['learn_rate']),
                           loss='categorical_crossentropy',
                           metrics=['accuracy'])



    def load_dataset(self):
        mnist = tf.keras.datasets.mnist
        (x_train, y_train), (x_test, y_test) = mnist.load_data()
        x_train, x_test = x_train / 255.0, x_test / 255.0
        self.x_train = x_train.reshape((x_train.shape[0], x_train.
                                   shape[1]*x_train.shape[2]))
        self.x_test = x_test.reshape((x_test.shape[0], x_test.
                                 shape[1]*x_test.shape[2]))

        self.y_train = tf.keras.utils.to_categorical(y_train,
                                                num_classes=10, dtype='float')
        self.y_test = tf.keras.utils.to_categorical(y_test,
                                               num_classes=10,
                                               dtype='float')

    def train(self):
    
        # Training model
        init_time = time.time()
        self.model.fit(self.x_train, self.y_train, epochs=self.dict_params['epochs'],
                  batch_size=self.dict_params['batch_size'],
                  validation_data=(self.x_test, self.y_test))
        end_time = time.time()
        print("Time elapsed in training: %f seconds" % (end_time - init_time))
        self.model.save_weights(self.dict_params['model_name'])


    def prune_model_wo_ft(self):
        # processing mnist dataset

        weights_model = self.model.get_weights()
        loss, acc = self.model.evaluate(x=self.x_test, y=self.y_test, batch_size=256)
        compl = regs_with_l0.calc_complexity(self.model.get_weights())
        print("Acc/Compl before pruning: %f\t%d" % (acc, compl))

        self.model.set_weights(regs_with_l0.weight_fc_prune(weights_model, self.dict_params['threshold']))
        self.model.save_weights(self.dict_params['model_pruned_name'])

        loss, acc = self.model.evaluate(x=self.x_test, y=self.y_test, batch_size=256)
        compl = regs_with_l0.calc_complexity(self.model.get_weights())

        self.model.save_weights(self.dict_params['model_pruned_name'])

        del weights_model
        print("Acc/Compl after pruning: %f\t%d" % (acc, compl))

    def prune_model(self):
        # processing mnist dataset
        loss, acc = self.model.evaluate(x=self.x_test, y=self.y_test, batch_size=256)
        compl = regs_with_l0.calc_complexity(self.model.get_weights())
        print("Acc/Compl before pruning: %f\t%d" % (acc, compl))

        for i in range(self.dict_params['ft_times']):
            weights_model = self.model.get_weights()
            self.model.set_weights(regs_with_l0.weight_fc_prune(weights_model, self.dict_params['threshold']))
            loss, acc = self.model.evaluate(x=self.x_test, y=self.y_test, batch_size=256)
            compl = regs_with_l0.calc_complexity(self.model.get_weights())
            print("Acc/Compl after pruning #%d:  %f\t%d" % (i, acc, compl))
            self.model.fit(self.x_train, self.y_train, epochs=self.dict_params['epochs_to_prune'],
                      batch_size=self.dict_params['batch_size'],
                      validation_data=(self.x_test, self.y_test))

        self.model.save_weights(self.dict_params['model_pruned_name'])

