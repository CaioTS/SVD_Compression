import tensorflow as tf 
from tensorflow.python.keras import backend as K
from tensorflow.python.ops import math_ops
import keras
import numpy as np

# Custom Regularizations
class L2L0_Reg(keras.regularizers.Regularizer):

  def __init__(self, l0=0., beta=0, l1=0., l2=0.):  # pylint: disable=redefined-outer-name
    self.l0 = K.cast_to_floatx(l0)
    self.beta = K.cast_to_floatx(beta)
    self.l1 = K.cast_to_floatx(l1)
    self.l2 = K.cast_to_floatx(l2)

  def __call__(self, x):
    if not self.l2 and not self.l0:
      return K.constant(0.)
    regularization = 0.
    if self.l0:
      ones_tensor = tf.ones(x.shape)
      regularization += self.l0 * math_ops.reduce_sum(ones_tensor-math_ops.exp(-self.beta*math_ops.abs(x)))
    if self.l2:
      regularization += self.l2 * math_ops.reduce_sum(math_ops.square(x))
    return regularization


    def get_config(self):
        return {'l0': float(self.l0), 'beta': float(self.beta), 'l2': float(self.l2)}    
    
def l0_exp(l0=0.01, l1=0.1, l2=0.1, beta=10):
  return L2L0_Reg(l0=l0, beta=beta, l1=0, l2=l2)

def weight_fc_prune(network_weights, threshold = 0.02):
  for layer_pos, weights in enumerate(network_weights):
    low_value_indices = np.abs(weights) < 0.1
    network_weights[layer_pos][low_value_indices] = 0
  return network_weights

def calc_complexity(weights_arr):
  compl = 0
  for layer_pos, weights in enumerate(weights_arr):
      compl += np.count_nonzero(weights)
  return compl
  
    
